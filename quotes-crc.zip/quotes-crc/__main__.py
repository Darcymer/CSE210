from quotes.board import Board
from quotes.quote import Quote
board = Board()
board.add_quote(Quote("Paul","God hath not given us the spirit of fear; but of power, and of love, and of a sound mind.","2 Timothy 1:7"))
board.add_quote(Quote("Sister Elaine S. Dalton","Work hard to achieve your dreams. Don't let discouragement or mistakes delay you.","How to Dare Great Things"))
board.add_quote(Quote("Alma","If ye have faith ye hope for things which are not seen, which are true.","Alma 32:21"))
board.add_quote(Quote("Alma","Live in thanksgiving daily.","Alma 34:38"))
board.add_quote(Quote("Alma","Counsel with the Lord in all thy doings, and he will direct thee for good.","Alma 37:37"))
board.start_board()




'''
You want to create a board that will hold quotes.
You need to be able to add and remove quotes from the board.
Quotes know their quote, author, and source. A quote can 
print itself out nicely and can tell you if an author 
is its author or not.
The board can show all quotes, get a random quote, and can 
list all quotes from an author
'''