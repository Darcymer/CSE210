class Quote:

    def __init__(self,author,quote,source=""):
        self.author = author
        self.quote = quote
        self.source = source

    def has_author(self,name):
        return name in self.author

    def get_quote(self):
        return f"\"{self.quote}\"\n{self.author} - {self.source}"

