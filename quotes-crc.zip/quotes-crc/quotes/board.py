import random
from quotes.quote import Quote
class Board:

    def __init__(self):
        self.quotes = []

    def nice_print(self,item):
        print("-"*64)
        print(item)
        print()
        print("-"*64) 

    def show_quotes(self):
        
        for quote in self.quotes:
            self.nice_print(quote.get_quote())


    def add_quote(self,quote):
        self.quotes.append(quote)
    
    def get_random_quote(self):
        self.nice_print(random.choice(self.quotes).get_quote())

    def find_quotes_by_author(self,author):
        for quote in self.quotes:
            if quote.has_author(author):
                self.nice_print(quote.get_quote())

    def start_board(self):
        response = ""
        while response not in ['Q']:
            while response not in ['A','S','Q','F','R']:
                response = input("What do you want to do?\n[A]dd quote:\n[S]how quotes\n[Q]uit\n[F]ind Quotes by Author\n[R]andom Quote\n").upper()
            if response == 'Q':
                exit()
            elif response == 'A':
                quote = input("Please enter your quote: ")
                author = input("Please enter the author: ")
                source = input("Please enter the source: ")
                self.add_quote(Quote(author,quote,source))
            elif response == 'S':
                self.show_quotes()
            elif response == 'F':
                author = input("Enter the person's name: ")
                self.find_quotes_by_author(author)
            elif response == 'R':
                self.get_random_quote()
            response = ""

        

# b = Board()
# q = Quote("Adam Hayes","I am He","1 Adams 1:1")
# b.add_quote(q)
# b.show_quotes()
