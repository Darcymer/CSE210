from fnmatch import fnmatchcase


class Student:

    def __init__(self,fname,lname):
        self._firstname = fname
        self._lastname = lname
    
    def show_name(self):
        return f"{self._firstname} {self._lastname}"

    @property
    def firstname(self):
        return self._firstname

    @property
    def lastname(self):
        return self._lastname

    @firstname.setter
    def firstname(self,fname):
        self._firstname = fname

    # def get_firstname(self):
    #     return self._firstname
    
    def set_firstname(self,fname):
        self._firstname = fname


julie = Student("Julie","Cowley")
print(julie.show_name())
print(julie.firstname)
julie.firstname = "Bob"
print(julie.firstname)