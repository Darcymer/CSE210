class Base:

    def __init__(self,word):
        self._word = word

    @property
    def word(self):
        return self._word

    # @word.setter
    # def word(self,word):
    #     self._word = word


x = Base('hello')
print(x.word)
# x.word = 'goodbye'
# print(x.word)
