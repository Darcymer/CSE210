class Log:

    def __init__(self,time,date,item):
        self._time = time
        self._date = date
        self._item = item
        pass