class Person:

    def __init__(self):
        pass

adam = Person()
print(adam)

heather = Person()
print(heather)