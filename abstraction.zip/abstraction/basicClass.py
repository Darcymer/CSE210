class Person:
    pass


adam = Person()
print(adam)

adam.full_name = "Adam Hayes"
print(adam.full_name)

# if __name__ == "__main__":
#     main()